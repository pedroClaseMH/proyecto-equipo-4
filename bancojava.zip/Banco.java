/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.curso_2526.ud_04.Hoja_06_2;

/**
 *
 * @author subie
 */
public class Banco {
    
    private Cliente[] misClientes;
    private int numeroClientes;
    
    
    public Banco(){
        
    }
    
    public Banco(int maximo){
        this.misClientes = new Cliente[maximo];
        this.numeroClientes = 0;
    }

    public Cliente[] getMisClientes() {
        return misClientes;
    }

    public int getNumeroClientes() {
        return numeroClientes;
    }

    public boolean estaLleno(){
        return numeroClientes >= misClientes.length;
    }
    //dar de alta cliente
   public boolean altaCliente(Cliente c){
    if (misClientes == null || estaLleno()) {
        return false;
    }

    for (int i = 0; i < misClientes.length; i++) {
        if (misClientes[i] == null) {
            misClientes[i] = c;
            numeroClientes++;
            return true;
        }
    }

    return false;
}

    //dar de alta Pro
   public boolean altaClientePRO(Cliente c){
    boolean insertado = false;

    if (misClientes != null && !estaLleno()) {
        for (int i = 0; i < misClientes.length && !insertado; i++) {
            if (misClientes[i] == null) {
                misClientes[i] = c;
                numeroClientes++;
                insertado = true;
            }
        }
    }

    return insertado;
}

    
   //buscar por código: el método recibe un código y devuelve un objeto Cliente o null.
   
   /**
    * 
    * @param codigo
    * @return Cliente
    */
   
   public Cliente buscarCliente(String codigo){
       Cliente cliente = null;
       
       for(Cliente c : misClientes){
        // FILTRO: Solo preguntamos el código si la posición NO es nula
        if(c != null){ 
            if(c.getCodigo().equalsIgnoreCase(codigo)){
                cliente = c;
                break;
           }
               
       }
       
   }
       return cliente;
   }
   
   //eliminar un cliente: busco si hay ese código y en qué posición está. reordeno a partir de ahí. devuelvo true / false
   /**
    * 
    * @param codigo 
    * @return boolean
    */
   public boolean eliminarCliente(String codigo){
    
       if(misClientes != null){
           for(int i = 0; i < numeroClientes; i++){
               if(misClientes[i] != null && misClientes[i].getCodigo().equalsIgnoreCase(codigo)){
                   
                   
                   for(int j = i; j < numeroClientes - 1; j++){
                       misClientes[j] = misClientes[j+1];
                   }
                   misClientes[numeroClientes] = null;
                   numeroClientes--;
                   return true;
               }
           }
           
       }
       
       
       
       return false;
   }
   
   
   
   
   
    @Override
    public String toString() {
        return "Banco{" + "misClientes=" + misClientes + ", numeroClientes=" + numeroClientes + '}';
    }
    
    
    
}
