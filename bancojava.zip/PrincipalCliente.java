/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package es.curso_2526.ud_04.Hoja_06_2;

import java.util.Scanner;

/**
 *
 * @author subie
 */
public class PrincipalCliente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Banco b1 = new Banco(10);
        Banco b2 = new Banco();
        Scanner entrada = new Scanner(System.in);
        int opcion = 0;

        Cliente c = new Cliente("pe", "ge", "56665", 80.99);
        System.out.println(c);

        do {
            menu();
            opcion = entrada.nextInt();
            entrada.nextLine();

            switch (opcion) {
                case 1 -> {
                    System.out.println("Dar de Alta un cliente en el Banco.");

                    if (altaCliente(entrada, b1)) {
                        System.out.println("Cliente dado de alta correctamente");
                    } else {
                        System.out.println("EL cliente no pudo darse de alta");
                    }
                }
                case 2 -> {
                    System.out.println("Mostrar los Usuarios del Banco");
                    mostrarClientes(b1);
                }
                case 3 ->{System.out.println("Buscando Cliente");
                   Cliente cliente = buscarClientePorCodigo(entrada, b1);
                   if(cliente != null){
                       System.out.println(cliente);
                   } else{
                       System.out.println("El cliente no existe");
                   }
                    
                }
                    
                case 4 ->{System.out.println("Dar de Baja");
                    if(eliminarClientePorCodigo(entrada, b1)){
                        System.out.println("Cliente dado de baja correctamente");
                    }else{
                        System.out.println("El cliente no existe");
                    }
                }
                    
                    
                    
                    
                    
                case 5 ->{
                    System.out.println("Saliendo del programa...");
                    salir();
                }
                    
                default ->
                    System.out.println("Opciones válidas números enteros de 1-5");
            }
        } while (opcion != 5);

        entrada.close();

    }

    public static void menu() {

        System.out.println("MENÚ OPCIONES CLIENTE");
        System.out.println("1. Dar de Alta Cliente");
        System.out.println("2. Mostrar los Usuarios del Banco");
        System.out.println("3. Buscar Cliente");
        System.out.println("4. Dar de Baja");
        System.out.println("5. Salir");
        System.out.println("Introduce una Opción (1 - 5)");

    }

    //1 Alta Cliente
    public static boolean altaCliente(Scanner entrada, Banco banco) {
        
        Cliente cliente = leerDatos(entrada);
        
        return banco.altaCliente(cliente);
    }

    //2 Mostrar CLientes
    public static void mostrarClientes(Banco banco) {
        System.out.println("Listado de Clientes del Banco");
        if (banco.getMisClientes() != null && banco.getNumeroClientes() > 0) {
            for (Cliente misCliente : banco.getMisClientes()) {
                if (misCliente != null) {
                    System.out.println(misCliente);
                }
            }

        }

    }
    //3 Buscar cliente por código
    public static Cliente buscarClientePorCodigo(Scanner sc, Banco banco){
        System.out.println("Introduce el código del cliente:");
        String codigo = sc.nextLine().toUpperCase();
        Cliente clienteBuscado = banco.buscarCliente(codigo);
        return clienteBuscado;
        
    }
    //4 Dar de baja cliente por código
    public static boolean eliminarClientePorCodigo(Scanner sc, Banco banco){
        System.out.println("Introduce el código del cliente a eliminar");
        String codigo = sc.nextLine().toUpperCase();
        boolean eliminado = banco.eliminarCliente(codigo);
        return eliminado;
    }
    
    // 5 Salir de la aplicación
    public static void salir(){
            System.out.println("El programa ha terminado");
}
    
   //6 crear un objeto cliente
    public static Cliente leerDatos(Scanner entrada){
        System.out.println("Introduce el nombre del cliente:");
        String nombre = entrada.nextLine();
        System.out.println("Introduce los apellidos del cliente");
        String apellidos = entrada.nextLine();
        System.out.println("Introduce el número de teléfono del cliente");
        
            String telefono = entrada.nextLine();
            System.out.println("Introduce el saldo inicial de la cuenta");
            Double saldo = entrada.nextDouble();
            entrada.nextLine();
            Cliente nuevo = new Cliente(nombre, apellidos, telefono, saldo);

            return nuevo;
            

        
    
    }
    
}   
