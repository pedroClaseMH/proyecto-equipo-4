/*
 *código, nombre, apellidos, teléfono y saldo junto con los métodos necesarios para su manipulación. 
 */
package es.curso_2526.ud_04.Hoja_06_2;

/**
 *
 * @author subie
 */
public class Cliente {
    
    private String codigo;//lo voy a dejar así, pero poner final sería adecuado porque una vez creado no debiera ser modificado
    private String nombre;
    private String apellidos;
    private String telefono;
    private double saldo;
    private static int contador = 0;

    public Cliente(String nombre, String apellidos, String telefono, double saldo) {
        this.codigo = String.format("CLI-%03d", ++contador);
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.telefono = telefono;
        setSaldo(saldo);
        
    }

    public String getCodigo() {
        return codigo;
    }

 //no ponemos setCodigo porque si es un código autogenerado, no parece razonable que sea modificable desde fuera.

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public double getSaldo() {
        return saldo;
    }
    //ponemos este pero sería mejor quitar public porque de ese modo sólo Banco podría modificar los saldo
   public final void setSaldo(double saldo) {
       
        this.saldo = (saldo > 0) ? saldo : 0;
    }

    public static int getContador(){
        return contador;
    }
    
   
    
    @Override
    public String toString() {
        return String.format("Cliente [ID: %s] | Nombre Completo: %s %s | Teléfono: %s | Saldo: %.2f €", 
                codigo, nombre, apellidos, telefono, saldo);
    }
    
    
    
    
    
    
    
    
}
